
# RSI Stock Analyzer App

This is a corrected project structure compatible with Android Studio.

## Instructions
1. Extract the ZIP file
2. Open Android Studio → File → Open → Select the extracted folder
3. Let Gradle sync and build
4. Run the app on your device or emulator

Includes basic setup to build from source. Extend features and logic as needed.
